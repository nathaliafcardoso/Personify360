package nathaliaFCardoso.Personify360;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Personify360ApplicationTests {

	@Test
	void contextLoads() {
	}

}
