package nathaliaFCardoso.Personify360;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Personify360Application {

	public static void main(String[] args) {
		SpringApplication.run(Personify360Application.class, args);
	}

}
